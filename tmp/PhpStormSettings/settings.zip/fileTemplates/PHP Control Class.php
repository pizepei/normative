<?php
#parse("PHP File Header.php")
#set( $Author = "皮泽培" )
#set( $Request = "Request $Request" )
/**
 * @Author: ${Author}
 * @ProductName: ${PROJECT_NAME}
 * @Created: ${DATE} ${TIME}
 * @baseAuth Resource:public
 * @title 控制器标题
 * @authGroup 权限组列表（在显示权限时继续分组）资源
 * @basePath /${NAME}  控制器下的根路由路径配置
 */
 
#if (${NAMESPACE})

namespace ${NAMESPACE};

use pizepei\staging\Controller;
use pizepei\staging\Request;

#end

class ${NAME} extends Controller{

    /**
     * @Author ${Author}
     * @Created ${DATE} ${TIME}
     *
     * @param ${Request}
     *   path [object] 路径参数
     *      uuid [string] 需要获取的uuid信息
     * @return array [json] 定义输出返回数据
     *      id [uuid] uuid
     *      name [object] 同学名字
     * @title  路由标题
     * @explain 路由功能说明
     * @authGroup basics.menu.getMenu:权限分组1,basics.index.menu:权限分组2
     * @authExtend UserExtend.list:拓展权限
     * @baseAuth Resource:public
     * @throws \Exception
     * @router get index/:uuid[string]
     */
     public function index(${Request})
     {
     
     }

}